using UnityEngine;

public class CarLeftToRight : MonoBehaviour
{
    public float speed = 5f;
    public float rightBoundary = 10f;
    public float leftStartPos = -10f;

    void Update()
    {
        transform.Translate(Vector3.right * speed * Time.deltaTime);

        if (transform.position.x > rightBoundary)
        {
            Vector3 pos = transform.position;
            pos.x = leftStartPos;
            transform.position = pos;
        }
    }
}
