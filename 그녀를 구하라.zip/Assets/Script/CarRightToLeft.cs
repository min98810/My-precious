using UnityEngine;

public class CarRightToLeft : MonoBehaviour
{
    public float speed = 5f;
    public float leftBoundary = -10f;
    public float rightStartPos = 10f;  // �����̵��� ������ ��ġ

    void Update()
    {
        transform.Translate(Vector3.left * speed * Time.deltaTime);

        if (transform.position.x < leftBoundary)
        {
            Vector3 pos = transform.position;
            pos.x = rightStartPos;
            transform.position = pos;
        }
    }
}
