﻿using UnityEngine;
using TMPro;  // TMP 텍스트 사용
using UnityEngine.SceneManagement;

public class DialogueManager : MonoBehaviour
{
    public GameObject dialoguePanel;          // 대화창 패널
    public TextMeshProUGUI dialogueText;      // TMP 텍스트

    public string[] sentences;                // 대사 목록

    private int index = 0;
    private bool isDialogueActive = false;

    private XYController playerController;

    void Start()
    {
        // Player 오브젝트 찾기 (태그: "Player")
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
            playerController = player.GetComponent<XYController>();

        dialoguePanel.SetActive(false);  // 시작할 때 대화창 숨김
    }

    public void StartDialogue()
    {
        if (sentences.Length == 0)
            return;

        isDialogueActive = true;
        index = 0;
        dialoguePanel.SetActive(true);
        dialogueText.text = sentences[index];

        // 플레이어 이동 제한
        if (playerController != null)
            playerController.enabled = false;
    }

    void Update()
    {
        if (!isDialogueActive)
            return;

        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space))
        {
            NextSentence();
        }
    }

    void NextSentence()
    {
        index++;
        if (index < sentences.Length)
        {
            dialogueText.text = sentences[index];
        }
        else
        {
            EndDialogue();
        }
    }

    void EndDialogue()
    {
        isDialogueActive = false;
        dialoguePanel.SetActive(false);

        // 플레이어 이동 다시 활성화
        if (playerController != null)
            playerController.enabled = true;

        // ✅ 타이머 시작 (있을 경우에만)
        GameTimer timer = FindObjectOfType<GameTimer>();
        if (timer != null)
        {
            timer.StartTimer();
        }
    }
}
