using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameTimer : MonoBehaviour
{
    public TextMeshProUGUI timerText;   // �ν����Ϳ� �Ҵ��ϰų� �� �ε� �� ã�Ƽ� ����
    public float timeRemaining = 20f;
    private bool timerIsRunning = false;

    private static GameTimer instance;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
            SceneManager.sceneLoaded += OnSceneLoaded;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // ���� �ٲ� ������ UI �ؽ�Ʈ �ٽ� ã�� ����
        timerText = GameObject.FindObjectOfType<TextMeshProUGUI>();

        if (timerText == null)
        {
            Debug.LogWarning("Timer TextMeshProUGUI not found in scene.");
        }

        // Victory ���̸� Ÿ�̸� UI ����� Ÿ�̸� ����
        if (scene.name == "Vicroty")
        {
            if (timerText != null)
                timerText.gameObject.SetActive(false);
            timerIsRunning = false;
        }
        else
        {
            if (timerText != null)
                timerText.gameObject.SetActive(true);
            UpdateTimerDisplay(timeRemaining);
        }
    }

    private void Start()
    {
        timerIsRunning = false;
        UpdateTimerDisplay(timeRemaining);
    }

    private void Update()
    {
        if (!timerIsRunning)
            return;

        if (timeRemaining > 0)
        {
            timeRemaining -= Time.deltaTime;
            UpdateTimerDisplay(timeRemaining);
        }
        else
        {
            timeRemaining = 0;
            timerIsRunning = false;
            UpdateTimerDisplay(timeRemaining);
            LoadFailScene();
        }
    }

    private void UpdateTimerDisplay(float time)
    {
        if (timerText == null)
            return;

        int minutes = Mathf.FloorToInt(time / 60);
        int seconds = Mathf.FloorToInt(time % 60);
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    private void LoadFailScene()
    {
        SceneManager.LoadScene("Fail");
    }

    public void StartTimer()
    {
        timerIsRunning = true;
    }
}
