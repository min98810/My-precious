﻿using UnityEngine;
using System.Collections;

public class PastSceneStart : MonoBehaviour
{
    private DialogueManager dialogueManager;

    void Start()
    {
        StartCoroutine(DelayedStartDialogue());
    }

    IEnumerator DelayedStartDialogue()
    {
        yield return null;

        dialogueManager = FindObjectOfType<DialogueManager>();

        if (dialogueManager != null)
        {
            dialogueManager.sentences = new string[]
            {
                "어..?",
                "정말 과거로 온거야?",
                "그럼 이럴 시간이 없어.",
                "빨리 그녀를..!"
            };

            dialogueManager.StartDialogue();
        }
    }

    // ✅ Teleport에서 호출할 수 있도록 이걸 추가
    public void StartDialogue()
    {
        StartCoroutine(DelayedStartDialogue());
    }
}
