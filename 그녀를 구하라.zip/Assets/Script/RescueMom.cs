using UnityEngine;
using UnityEngine.SceneManagement;

public class RescueMom : MonoBehaviour
{
    private bool rescued = false;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (rescued) return;

        if (collision.CompareTag("Player"))
        {
            rescued = true;
            SceneManager.LoadScene("Victory"); // �¸� ������ �̵�
        }
    }
}
