using UnityEngine;
using UnityEngine.SceneManagement;

public class Teleport : MonoBehaviour
{
    public string sceneToLoad = "PastInTheMirror";

    private bool isTeleporting = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isTeleporting) return;

        if (other.CompareTag("Player"))
        {
            isTeleporting = true;
            SceneManager.sceneLoaded += OnSceneLoaded;  // �� �ε� �Ϸ� �̺�Ʈ ����
            SceneManager.LoadScene(sceneToLoad);
        }
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name == sceneToLoad)
        {
            // ���� �ε�Ǹ� PastSceneStart ��ũ��Ʈ�� ��ȭ ���� �Լ� ȣ��
            PastSceneStart pastSceneStart = FindObjectOfType<PastSceneStart>();
            if (pastSceneStart != null)
            {
                pastSceneStart.StartDialogue();
            }

            // �̺�Ʈ ����
            SceneManager.sceneLoaded -= OnSceneLoaded;
            isTeleporting = false;
        }
    }
}
