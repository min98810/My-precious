﻿using UnityEngine;

namespace SupanthaPaul
{
    public class PlayerAnimator : MonoBehaviour
    {
        private Rigidbody2D m_rb;
        private XYController m_controller;
        private Animator m_anim;

        private static readonly int Move = Animator.StringToHash("Move");

        private void Start()
        {
            m_anim = GetComponentInChildren<Animator>();
            m_controller = GetComponent<XYController>();
            m_rb = GetComponent<Rigidbody2D>();
        }

        private void Update()
        {
            // 좌우 속도를 기반으로 달리기 애니메이션 제어
            float horizontalVelocity = Mathf.Abs(m_rb.velocity.x);
            m_anim.SetFloat(Move, horizontalVelocity);
        }
    }
}
